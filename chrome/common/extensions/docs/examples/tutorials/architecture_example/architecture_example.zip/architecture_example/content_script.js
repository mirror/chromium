// Copyright 2017 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

'use strict';

 chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
   document.body.style.backgroundColor = request.color;
   sendResponse({done: "background color is " + request.color});
 });

 function findBackgroundColor() {
  let backgroundColor = document.head.style.backgroundColor
  chrome.storage.sync.set({pageColor: backgroundColor});
};

findBackgroundColor();
